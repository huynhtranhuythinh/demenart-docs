// V113G.1 — Mobile top header (≤400px): sticky, safe-area aware, logo + bell.
// Utilities beyond notifications live via Hôm nay/utility surfaces, never in
// the bottom navigation.
import { Link } from "@tanstack/react-router";
import { Bell } from "lucide-react";
import { UnreadBadge } from "@/features/parent/shell/ParentBottomNav";

const LOGO_BANNER = "https://cdn.demenart.com/landing/logo-banner.webp";

export function MobileParentHeader({ unread }: { unread: number }) {
  return (
    <header className="sticky top-0 z-40 border-b border-dma-hairline bg-dma-ivory/95 pt-(--dma-safe-top) backdrop-blur dtab:hidden">
      <div className="flex items-center justify-between px-4 py-2.5">
        <Link to="/parent" className="inline-flex items-center">
          <img src={LOGO_BANNER} alt="Dế Mèn Art" className="h-8 w-auto" />
        </Link>
        <Link
          to="/portal/notifications"
          aria-label={unread > 0 ? `Thông báo, ${unread} chưa đọc` : "Thông báo"}
          className="relative inline-flex min-h-11 min-w-11 items-center justify-center rounded-full text-dma-ink-2"
        >
          <Bell className="h-5 w-5" aria-hidden="true" />
          <UnreadBadge unread={unread} />
        </Link>
      </div>
    </header>
  );
}
