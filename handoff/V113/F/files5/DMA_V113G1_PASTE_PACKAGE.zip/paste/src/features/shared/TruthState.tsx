// V113G.1 — Truthful state foundation (F4 TruthStateBlock grammar, G.1 subset).
// Foundation scope: loading · empty · error ONLY. The full nine-variant Pack-4
// system (denied/archived/consent states/media) is completed in V113G.8.
// Invariant: error ≠ empty, visually and semantically (F01/E4 — never silent-empty).
import { useId, type ReactNode } from "react";
import { cn } from "@/lib/utils";

type TruthStateAction = { label: string; onClick: () => void };

export function TruthState({
  state,
  title,
  description,
  action,
  children,
  className,
}: {
  state: "loading" | "empty" | "error";
  title: string;
  description?: string;
  /** Zero or one action. */
  action?: TruthStateAction | null;
  /** Optional extra content (e.g. a sole primary create action in true empty). */
  children?: ReactNode;
  className?: string;
}) {
  const titleId = useId();
  const descId = useId();

  if (state === "loading") {
    return (
      <div
        role="status"
        aria-live="polite"
        aria-busy="true"
        className={cn("rounded-3xl border border-dma-hairline bg-dma-ivory-raised p-8", className)}
      >
        <p className="text-sm font-medium text-dma-ink-2">{title}</p>
        <div className="mt-4 space-y-2.5">
          <div className="h-3 w-3/4 animate-pulse rounded-full bg-dma-sage-tint" />
          <div className="h-3 w-1/2 animate-pulse rounded-full bg-dma-sage-tint" />
          <div className="h-3 w-2/3 animate-pulse rounded-full bg-dma-sage-tint" />
        </div>
      </div>
    );
  }

  if (state === "error") {
    return (
      <div
        role="alert"
        className={cn(
          "rounded-3xl border border-dma-hairline border-l-4 border-l-dma-error bg-dma-ivory-raised p-8",
          className,
        )}
      >
        <p className="font-dma-serif text-lg text-dma-ink">{title}</p>
        {description && (
          <p className="mt-1.5 text-sm leading-relaxed text-dma-ink-2">{description}</p>
        )}
        {action && (
          <button
            type="button"
            onClick={action.onClick}
            className="mt-4 inline-flex min-h-11 items-center rounded-full bg-dma-emerald px-5 text-sm font-medium text-dma-ivory transition-colors hover:bg-dma-emerald-hover"
          >
            {action.label}
          </button>
        )}
      </div>
    );
  }

  return (
    <div
      aria-labelledby={titleId}
      aria-describedby={description ? descId : undefined}
      className={cn(
        "rounded-3xl border border-dashed border-dma-sage bg-dma-ivory-raised p-8 text-center sm:p-10",
        className,
      )}
    >
      <p id={titleId} className="font-dma-serif text-lg text-dma-ink">
        {title}
      </p>
      {description && (
        <p id={descId} className="mx-auto mt-2 max-w-md text-sm leading-relaxed text-dma-ink-2">
          {description}
        </p>
      )}
      {action && (
        <button
          type="button"
          onClick={action.onClick}
          className="mt-5 inline-flex min-h-11 items-center rounded-full bg-dma-emerald px-6 text-sm font-medium text-dma-ivory transition-colors hover:bg-dma-emerald-hover"
        >
          {action.label}
        </button>
      )}
      {children}
    </div>
  );
}
