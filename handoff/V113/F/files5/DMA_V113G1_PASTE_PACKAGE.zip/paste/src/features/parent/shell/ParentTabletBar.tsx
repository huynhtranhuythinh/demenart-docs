// V113G.1 — Tablet chrome (401–1023px, frozen): top bar + navigation drawer.
// No desktop rail, no mobile bottom nav, no icon rail. Drawer reuses the
// existing Radix Sheet: labelled dialog, focus containment, Esc close,
// non-destructive backdrop close, focus restored to the trigger.
import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Bell, LogOut, Menu } from "lucide-react";
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { PARENT_PRIMARY_NAV, PARENT_UTILITY_NAV } from "@/features/parent/shell/parentNav";
import { UnreadBadge } from "@/features/parent/shell/ParentBottomNav";

const LOGO_BANNER = "https://cdn.demenart.com/landing/logo-banner.webp";

export function ParentTabletBar({ unread, onSignOut }: { unread: number; onSignOut: () => void }) {
  const [open, setOpen] = useState(false);

  return (
    <header className="sticky top-0 z-40 hidden border-b border-dma-hairline bg-dma-ivory/95 pt-(--dma-safe-top) backdrop-blur dtab:block lg:hidden">
      <div className="flex items-center justify-between px-5 py-3">
        <Link to="/parent" className="flex items-center gap-3">
          <img src={LOGO_BANNER} alt="Dế Mèn Art" className="h-8 w-auto" />
          <span className="text-sm font-medium text-dma-ink-2">Cổng ba mẹ</span>
        </Link>
        <div className="flex items-center gap-1">
          <Link
            to="/portal/notifications"
            aria-label={unread > 0 ? `Thông báo, ${unread} chưa đọc` : "Thông báo"}
            className="relative inline-flex min-h-11 min-w-11 items-center justify-center rounded-full text-dma-ink-2 transition-colors hover:bg-dma-sage-tint"
          >
            <Bell className="h-5 w-5" aria-hidden="true" />
            <UnreadBadge unread={unread} />
          </Link>
          <button
            type="button"
            aria-label="Mở menu điều hướng"
            onClick={() => setOpen(true)}
            className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-full text-dma-ink-2 transition-colors hover:bg-dma-sage-tint"
          >
            <Menu className="h-5 w-5" aria-hidden="true" />
          </button>
        </div>
      </div>

      <Sheet open={open} onOpenChange={setOpen}>
        <SheetContent side="right" className="dma-parent flex w-80 flex-col bg-dma-ivory p-0">
          <SheetHeader className="border-b border-dma-hairline px-5 pt-5 pb-4 text-left">
            <SheetTitle className="font-dma-serif text-lg text-dma-ink">Điều hướng</SheetTitle>
            <SheetDescription className="text-xs text-dma-ink-meta">
              Cổng ba mẹ · Dế Mèn Art
            </SheetDescription>
          </SheetHeader>
          <nav aria-label="Điều hướng chính" className="flex-1 overflow-y-auto px-3 py-4">
            <ul className="space-y-1">
              {PARENT_PRIMARY_NAV.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      activeOptions={item.exact ? { exact: true } : undefined}
                      activeProps={{
                        "aria-current": "page",
                        className: "bg-dma-emerald text-dma-ivory",
                      }}
                      inactiveProps={{
                        className: "text-dma-ink-2 hover:bg-dma-sage-tint",
                      }}
                      onClick={() => setOpen(false)}
                      className="flex min-h-11 items-center gap-3 rounded-xl px-4 text-sm font-medium transition-colors"
                    >
                      <Icon className="h-4.5 w-4.5" aria-hidden="true" />
                      {item.labelDesktop}
                    </Link>
                  </li>
                );
              })}
            </ul>
            <p className="mt-6 px-4 text-[11px] font-semibold tracking-wide text-dma-ink-meta uppercase">
              Dành cho ba mẹ
            </p>
            <ul className="mt-2 space-y-1">
              {PARENT_UTILITY_NAV.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.to}>
                    <Link
                      to={item.to}
                      onClick={() => setOpen(false)}
                      className="flex min-h-11 items-center gap-3 rounded-xl px-4 text-sm text-dma-ink-2 transition-colors hover:bg-dma-sage-tint"
                    >
                      <span className="relative inline-flex" aria-hidden="true">
                        <Icon className="h-4.5 w-4.5" />
                        {item.isNotifications && <UnreadBadge unread={unread} />}
                      </span>
                      {item.label}
                    </Link>
                  </li>
                );
              })}
            </ul>
          </nav>
          <div className="border-t border-dma-hairline px-5 py-4">
            <button
              type="button"
              onClick={() => {
                setOpen(false);
                onSignOut();
              }}
              className="inline-flex min-h-11 items-center gap-2 rounded-full px-3 text-sm text-dma-ink-meta transition-colors hover:text-dma-ink"
            >
              <LogOut className="h-4 w-4" aria-hidden="true" />
              Đăng xuất
            </button>
          </div>
        </SheetContent>
      </Sheet>
    </header>
  );
}
