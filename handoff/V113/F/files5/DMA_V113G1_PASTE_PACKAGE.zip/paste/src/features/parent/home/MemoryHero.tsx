// V113G.1 — Hôm nay hero (F3 A1, L2 baseline): one large reserved-media memory,
// serif title, exactly ONE primary CTA ("Xem ký ức này") opening the item in
// the existing Hành trình flow. No KPI, no count before media, no ranking.
import { Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import { ReservedMedia, type ReservedMediaStatus } from "@/features/shared/ReservedMedia";

export function MemoryHero({
  kindLabel,
  title,
  blurb,
  dateLabel,
  mediaStatus,
  mediaSrc,
  focusId,
  onRetryMedia,
}: {
  kindLabel: string;
  title: string;
  blurb?: string | null;
  dateLabel: string;
  mediaStatus: ReservedMediaStatus;
  mediaSrc?: string | null;
  /** Timeline focus id (journey:/creation:/moment:) for the Hành trình deep link. */
  focusId: string;
  onRetryMedia?: () => void;
}) {
  return (
    <section
      aria-label="Ký ức mới nhất"
      className="overflow-hidden rounded-3xl border border-dma-hairline bg-dma-ivory-raised"
    >
      <ReservedMedia
        status={mediaStatus}
        src={mediaSrc}
        alt={title}
        ratio="16/9"
        onRetry={onRetryMedia}
        className="rounded-none"
      />
      <div className="p-6 sm:p-8">
        <p className="text-xs font-semibold tracking-wide text-dma-ink-gold uppercase">
          {kindLabel}
        </p>
        <h2 className="mt-2 font-dma-serif text-2xl leading-snug text-dma-ink sm:text-[1.75rem]">
          {title}
        </h2>
        {blurb && (
          <p className="mt-2 line-clamp-3 text-sm leading-relaxed whitespace-pre-line text-dma-ink-2">
            {blurb}
          </p>
        )}
        <p className="mt-3 text-xs text-dma-ink-meta">{dateLabel}</p>
        <div className="mt-5">
          <Link
            to="/parent/journal"
            search={{ focus: focusId }}
            className="inline-flex min-h-11 items-center gap-2 rounded-full bg-dma-emerald px-6 text-sm font-medium text-dma-ivory transition-colors hover:bg-dma-emerald-hover"
          >
            Xem ký ức này
            <ArrowRight className="h-4 w-4" aria-hidden="true" />
          </Link>
        </div>
      </div>
    </section>
  );
}
