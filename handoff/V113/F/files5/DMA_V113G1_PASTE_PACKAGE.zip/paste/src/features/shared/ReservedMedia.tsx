// V113G.1 — Reserved-media primitive (F4/F5): the box reserves its final aspect
// ratio BEFORE any signed URL resolves. Loading, success and failure all live
// inside the same box — zero layout collapse, zero shift, no autoplay,
// no broken-image icon.
import { type ReactNode } from "react";
import { cn } from "@/lib/utils";

export type ReservedMediaStatus = "loading" | "ok" | "failed" | "empty";

export function ReservedMedia({
  status,
  src,
  alt = "",
  ratio = "16/9",
  failedText = "Ảnh tạm thời chưa xem được",
  emptyText = "Chưa có hình ảnh",
  onRetry,
  overlay,
  className,
}: {
  status: ReservedMediaStatus;
  src?: string | null;
  alt?: string;
  ratio?: "16/9" | "4/3";
  failedText?: string;
  emptyText?: string;
  onRetry?: () => void;
  overlay?: ReactNode;
  className?: string;
}) {
  return (
    <div
      className={cn(
        "relative w-full overflow-hidden rounded-2xl bg-dma-sage-tint",
        ratio === "16/9" ? "aspect-video" : "aspect-4/3",
        className,
      )}
    >
      {status === "loading" && (
        <div
          role="status"
          aria-live="polite"
          aria-busy="true"
          aria-label="Đang tải hình ảnh"
          className="absolute inset-0 animate-pulse bg-dma-sage-tint"
        />
      )}
      {status === "ok" && src && (
        <img
          src={src}
          alt={alt}
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover"
        />
      )}
      {(status === "failed" || status === "empty") && (
        <div className="absolute inset-0 flex flex-col items-center justify-center gap-2 p-4 text-center">
          <p className="text-sm text-dma-ink-2">{status === "failed" ? failedText : emptyText}</p>
          {status === "failed" && onRetry && (
            <button
              type="button"
              onClick={onRetry}
              aria-label="Thử tải lại hình ảnh này"
              className="inline-flex min-h-11 min-w-11 items-center justify-center rounded-full border border-dma-hairline bg-dma-ivory-raised px-4 text-sm font-medium text-dma-ink-2 hover:bg-dma-sage-tint"
            >
              Thử lại
            </button>
          )}
        </div>
      )}
      {overlay}
    </div>
  );
}
