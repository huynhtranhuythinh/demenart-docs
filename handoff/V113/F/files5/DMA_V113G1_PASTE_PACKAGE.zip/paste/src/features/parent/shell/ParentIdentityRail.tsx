// V113G.1 — Desktop identity rail (≥1024px). L2 Journey baseline: deep-emerald
// identity column, official logo on an ivory plate, four frozen primaries,
// utilities separated, quiet account/footer zone. No ChildSwitcher here in G.1
// (adoption boundary: Hôm nay owns the switcher until G.2 migrates the rest).
import { Link } from "@tanstack/react-router";
import { LogOut } from "lucide-react";
import { PARENT_PRIMARY_NAV, PARENT_UTILITY_NAV } from "@/features/parent/shell/parentNav";
import { UnreadBadge } from "@/features/parent/shell/ParentBottomNav";

const LOGO_BANNER = "https://cdn.demenart.com/landing/logo-banner.webp";

export function ParentIdentityRail({
  profileName,
  unread,
  onSignOut,
}: {
  profileName: string;
  unread: number;
  onSignOut: () => void;
}) {
  return (
    <aside className="sticky top-0 hidden h-screen w-(--dma-rail-w) shrink-0 flex-col bg-dma-emerald-identity text-dma-ivory lg:flex">
      <div className="px-6 pt-8">
        <Link to="/parent" className="inline-flex rounded-2xl bg-dma-ivory px-4 py-3">
          <img src={LOGO_BANNER} alt="Dế Mèn Art" className="h-9 w-auto" />
        </Link>
        <p className="mt-5 font-dma-serif text-lg leading-snug text-dma-ivory">
          Hành trình của con
        </p>
        <p className="mt-1 text-xs text-dma-sage">Cổng ba mẹ · Dế Mèn Art</p>
      </div>

      <nav aria-label="Điều hướng chính" className="mt-8 flex-1 overflow-y-auto px-3">
        <ul className="space-y-1">
          {PARENT_PRIMARY_NAV.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  activeOptions={item.exact ? { exact: true } : undefined}
                  activeProps={{
                    "aria-current": "page",
                    className: "bg-dma-emerald text-dma-ivory border-l-2 border-dma-champagne",
                  }}
                  inactiveProps={{
                    className:
                      "border-l-2 border-transparent text-dma-sage hover:bg-dma-emerald hover:text-dma-ivory",
                  }}
                  className="flex min-h-11 items-center gap-3 rounded-xl px-4 text-sm font-medium transition-colors"
                >
                  <Icon className="h-4.5 w-4.5" aria-hidden="true" />
                  <span>{item.labelDesktop}</span>
                </Link>
              </li>
            );
          })}
        </ul>

        <p className="mt-8 px-4 text-[11px] font-semibold tracking-wide text-dma-sage uppercase">
          Dành cho ba mẹ
        </p>
        <ul className="mt-2 space-y-1">
          {PARENT_UTILITY_NAV.map((item) => {
            const Icon = item.icon;
            return (
              <li key={item.to}>
                <Link
                  to={item.to}
                  className="flex min-h-11 items-center gap-3 rounded-xl px-4 text-sm text-dma-sage transition-colors hover:bg-dma-emerald hover:text-dma-ivory"
                >
                  <span className="relative inline-flex" aria-hidden="true">
                    <Icon className="h-4.5 w-4.5" />
                    {item.isNotifications && <UnreadBadge unread={unread} />}
                  </span>
                  <span>{item.label}</span>
                  {item.isNotifications && unread > 0 && (
                    <span className="sr-only">, {unread} thông báo chưa đọc</span>
                  )}
                </Link>
              </li>
            );
          })}
        </ul>
      </nav>

      <div className="border-t border-dma-emerald px-6 py-5">
        <p className="truncate text-sm text-dma-ivory">{profileName}</p>
        <p className="text-xs text-dma-sage">Phụ huynh</p>
        <button
          type="button"
          onClick={onSignOut}
          className="mt-3 inline-flex min-h-11 items-center gap-2 rounded-full px-3 text-sm text-dma-sage transition-colors hover:text-dma-ivory"
        >
          <LogOut className="h-4 w-4" aria-hidden="true" />
          Đăng xuất
        </button>
      </div>
    </aside>
  );
}
