// V113G.1 — Frozen Parent navigation model (F1/F3/F5, V113F PASS).
// Exactly four primary destinations. Utilities are never primary navigation.
import {
  Bell,
  BookHeart,
  LifeBuoy,
  Settings,
  ShieldCheck,
  Sparkles,
  Sun,
  Users,
  type LucideIcon,
} from "lucide-react";

export type ParentPrimaryNavItem = {
  to: string;
  /** Desktop + tablet label. */
  labelDesktop: string;
  /** Mobile bottom-nav label (frozen: item 4 = "Của con"). */
  labelMobile: string;
  icon: LucideIcon;
  exact?: boolean;
};

export const PARENT_PRIMARY_NAV: readonly ParentPrimaryNavItem[] = [
  { to: "/parent", labelDesktop: "Hôm nay", labelMobile: "Hôm nay", icon: Sun, exact: true },
  { to: "/parent/journal", labelDesktop: "Hành trình", labelMobile: "Hành trình", icon: BookHeart },
  { to: "/parent/family", labelDesktop: "Gia đình", labelMobile: "Gia đình", icon: Users },
  {
    to: "/parent/kid",
    labelDesktop: "Thế giới của con",
    labelMobile: "Của con",
    icon: Sparkles,
  },
] as const;

export type ParentUtilityNavItem = {
  to: string;
  label: string;
  icon: LucideIcon;
  /** Marks the notifications entry so shells can attach the unread badge. */
  isNotifications?: boolean;
};

export const PARENT_UTILITY_NAV: readonly ParentUtilityNavItem[] = [
  { to: "/parent/consent", label: "Quyền riêng tư", icon: ShieldCheck },
  { to: "/portal/notifications", label: "Thông báo", icon: Bell, isNotifications: true },
  { to: "/parent/settings", label: "Cài đặt", icon: Settings },
  { to: "/portal/support", label: "Hỗ trợ", icon: LifeBuoy },
] as const;
