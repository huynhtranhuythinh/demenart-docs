// V113G.1 — Shared semantic ChildSwitcher (F4/F5, Pack 2 grammar).
// Reads/writes ONLY through the persisted ParentChildProvider context.
// G.1 adoption boundary: mounted by Hôm nay only; Journey/Discovery keep their
// route-local selectors until V113G.2 migrates them.
import { childLabel, useParentChild } from "@/features/parent/parentChildContext";
import { cn } from "@/lib/utils";

type ChildSwitcherVariant = "chips" | "compact";

export function ChildSwitcher({
  variant = "chips",
  className,
}: {
  variant?: ChildSwitcherVariant;
  className?: string;
}) {
  const { children, selectedChildId, setSelectedChildId } = useParentChild();

  if (!children || children.length < 2) return null;

  return (
    <div
      role="group"
      aria-label="Chọn con"
      className={cn("flex flex-wrap items-center gap-2", className)}
    >
      {children.map((c) => {
        const active = c.id === selectedChildId;
        const label = childLabel(c);
        return (
          <button
            key={c.id}
            type="button"
            aria-pressed={active}
            aria-label={active ? `${label}, đang chọn` : label}
            onClick={() => setSelectedChildId(c.id)}
            className={cn(
              "inline-flex min-h-11 min-w-11 items-center justify-center rounded-full border text-sm font-medium transition-colors",
              variant === "compact" ? "px-3.5" : "px-5",
              active
                ? "border-dma-emerald bg-dma-emerald text-dma-ivory shadow-sm"
                : "border-dma-hairline bg-dma-ivory-raised text-dma-ink-2 hover:bg-dma-sage-tint",
            )}
          >
            {label}
          </button>
        );
      })}
    </div>
  );
}
