// V113G.1 — Parent shell: frozen emerald/ivory foundation (V113F PASS).
// Desktop ≥1024: identity rail · Tablet 401–1023: top bar + drawer ·
// Mobile ≤400: header + four-item bottom nav ("Của con").
// Preserved exactly: ParentChildProvider wiring, auth/sign-out contract,
// notification polling + realtime, InAppBrowserNotice, Outlet rendering.
import { createFileRoute, Outlet, useNavigate } from "@tanstack/react-router";
import { useQueryClient } from "@tanstack/react-query";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useCurrentProfile } from "@/hooks/use-current-profile";
import { useRealtimeNotifications } from "@/hooks/use-realtime-notifications";
import { ParentChildProvider } from "@/features/parent/parentChildContext";
import { InAppBrowserNotice } from "@/components/InAppBrowserNotice";
import { ParentIdentityRail } from "@/features/parent/shell/ParentIdentityRail";
import { ParentTabletBar } from "@/features/parent/shell/ParentTabletBar";
import { MobileParentHeader } from "@/features/parent/shell/MobileParentHeader";
import { ParentBottomNav } from "@/features/parent/shell/ParentBottomNav";

export const Route = createFileRoute("/_authenticated/parent")({
  component: ParentLayout,
});

function ParentLayout() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const { profile, user } = useCurrentProfile();
  const [unread, setUnread] = useState<number>(0);

  const loadUnread = useCallback(async () => {
    if (typeof window === "undefined" || !user?.id) return;
    const { count } = await supabase
      .from("notifications")
      .select("id", { count: "exact", head: true })
      .eq("read", false);
    setUnread(count ?? 0);
  }, [user?.id]);

  useEffect(() => {
    if (typeof window === "undefined" || !user?.id) return;
    loadUnread();
    const interval = window.setInterval(loadUnread, 60_000);
    return () => {
      window.clearInterval(interval);
    };
  }, [user?.id, loadUnread]);

  useRealtimeNotifications(profile?.id, loadUnread);

  async function handleSignOut() {
    await queryClient.cancelQueries();
    queryClient.clear();
    await supabase.auth.signOut();
    navigate({ to: "/auth", replace: true });
  }

  const profileName = profile?.full_name ?? user?.email ?? "";

  return (
    <ParentChildProvider>
      <div className="dma-parent min-h-screen lg:flex">
        <ParentIdentityRail profileName={profileName} unread={unread} onSignOut={handleSignOut} />
        <div className="flex min-w-0 flex-1 flex-col">
          <ParentTabletBar unread={unread} onSignOut={handleSignOut} />
          <MobileParentHeader unread={unread} />
          <main className="mx-auto w-full max-w-4xl flex-1 px-4 py-6 pb-[calc(var(--dma-bottomnav-h)+var(--dma-safe-bottom)+1.5rem)] dtab:px-6 dtab:py-8 dtab:pb-10">
            <div className="mb-4">
              <InAppBrowserNotice />
            </div>
            <Outlet />
          </main>
          <ParentBottomNav />
        </div>
      </div>
    </ParentChildProvider>
  );
}
