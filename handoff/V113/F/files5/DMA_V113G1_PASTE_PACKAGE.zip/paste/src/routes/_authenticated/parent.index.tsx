// V113G.1 — Hôm nay (canonical Home, F3 A1 · V113F PASS).
// Order: identity → ChildSwitcher → hero memory → primary "Xem ký ức này" →
// quiet supporting areas → recent strip → family signal (preserved journal
// entries) → contextual create → truthful empty/error.
// One primary action. No KPI tiles. Counts appear only as quiet metadata.
// Data contracts unchanged: get_child_journal RPC + get_signed_media_url Edge.
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useCallback, useEffect, useRef, useState } from "react";
import { ArrowRight, ChevronRight, HeartHandshake, KeyRound, Plus, Sparkles } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useParentChild, childLabel } from "@/features/parent/parentChildContext";
import { ChildSwitcher } from "@/features/parent/ChildSwitcher";
import { MemoryHero } from "@/features/parent/home/MemoryHero";
import { TruthState } from "@/features/shared/TruthState";
import { type ReservedMediaStatus } from "@/features/shared/ReservedMedia";
import { ParentMemoryComposer } from "@/features/journey/ParentMemoryComposer";
import {
  buildParentTimeline,
  cleanCaption,
  formatViDate,
  isFamilyPreserve,
  isParentMemory,
  type JournalPayload,
  type ParentTimelineEvent,
} from "@/features/journey/parentJourneyModel";
import { logParentEvent } from "@/lib/parentTelemetry";

export const Route = createFileRoute("/_authenticated/parent/")({
  component: ParentHome,
});

type HeroModel = {
  focusId: string;
  kindLabel: string;
  title: string;
  blurb: string | null;
  dateLabel: string;
  mediaId: string;
};

/**
 * Deterministic hero selection: walk buildParentTimeline (already sorted
 * occurredAt DESC with stable input order) and take the FIRST event carrying
 * usable visual media. An item without usable media is never selected while a
 * media-bearing item exists.
 */
function pickHero(data: JournalPayload): HeroModel | null {
  const events = buildParentTimeline(data);
  for (const ev of events) {
    const model = heroFromEvent(ev);
    if (model) return model;
  }
  return null;
}

function heroFromEvent(ev: ParentTimelineEvent): HeroModel | null {
  if (ev.source === "moment") {
    if (!ev.moment.media_id) return null;
    return {
      focusId: ev.id,
      kindLabel: "Khoảnh khắc ở lớp",
      title: cleanCaption(ev.moment.caption) || "Một khoảnh khắc ở lớp",
      blurb: null,
      dateLabel: formatViDate(ev.moment.created_at),
      mediaId: ev.moment.media_id,
    };
  }
  if (ev.source === "creation") {
    if (ev.creation.kind !== "drawing" || !ev.creation.media_id) return null;
    return {
      focusId: ev.id,
      kindLabel: "Tác phẩm của con",
      title: cleanCaption(ev.creation.caption) || "Tác phẩm mới của con",
      blurb: null,
      dateLabel: formatViDate(ev.creation.created_at),
      mediaId: ev.creation.media_id,
    };
  }
  if (isParentMemory(ev.entry) && ev.entry.parent_memory) {
    const pm = ev.entry.parent_memory;
    const firstImage = (pm.galleryItems ?? [])
      .filter((it) => (it.fileType ?? "").startsWith("image/"))
      .slice()
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))[0];
    if (!firstImage) return null;
    return {
      focusId: ev.id,
      kindLabel: "Ba mẹ lưu lại",
      title: pm.title,
      blurb: pm.story,
      dateLabel: formatViDate(ev.entry.occurred_at),
      mediaId: firstImage.mediaId,
    };
  }
  if (isFamilyPreserve(ev.entry) && ev.entry.family_preserve) {
    const fp = ev.entry.family_preserve;
    const firstImage = (fp.galleryItems ?? [])
      .filter((it) => (it.fileType ?? "").startsWith("image/"))
      .slice()
      .sort((a, b) => (a.sortOrder ?? 0) - (b.sortOrder ?? 0))[0];
    if (!firstImage) return null;
    return {
      focusId: ev.id,
      kindLabel: "Từ Không gian gia đình",
      title: fp.card_title || "Kỷ niệm gia đình",
      blurb: fp.card_story,
      dateLabel: formatViDate(ev.entry.occurred_at),
      mediaId: firstImage.mediaId,
    };
  }
  return null;
}

type RecentLeaf = {
  focusId: string;
  emoji: string;
  label: string;
  text: string | null;
  dm: string;
};

function buildRecent(data: JournalPayload): RecentLeaf[] {
  const out: RecentLeaf[] = [];
  for (const ev of buildParentTimeline(data)) {
    if (ev.source === "creation") {
      const isDraw = ev.creation.kind === "drawing";
      out.push({
        focusId: ev.id,
        emoji: isDraw ? "🎨" : "🎵",
        label: isDraw ? "Tác phẩm mới" : "Âm thanh của con",
        text: cleanCaption(ev.creation.caption) || null,
        dm: formatViDate(ev.occurredAt),
      });
    } else if (ev.source === "moment") {
      if (!ev.moment.media_id) continue;
      out.push({
        focusId: ev.id,
        emoji: "📸",
        label: "Khoảnh khắc ở lớp",
        text: cleanCaption(ev.moment.caption) || null,
        dm: formatViDate(ev.occurredAt),
      });
    } else if (isFamilyPreserve(ev.entry) && ev.entry.family_preserve) {
      out.push({
        focusId: ev.id,
        emoji: "🏡",
        label: "Từ Không gian gia đình",
        text: ev.entry.family_preserve.card_title || ev.entry.family_preserve.contribution_body,
        dm: formatViDate(ev.occurredAt),
      });
    } else if (isParentMemory(ev.entry) && ev.entry.parent_memory) {
      out.push({
        focusId: ev.id,
        emoji: "🏡",
        label: "Ba mẹ lưu lại",
        text: ev.entry.parent_memory.title,
        dm: formatViDate(ev.occurredAt),
      });
    } else if (ev.source === "journey" && ev.entry.entry_type === "session") {
      out.push({
        focusId: ev.id,
        emoji: "🚌",
        label: "Buổi học",
        text: ev.entry.session_title ?? ev.entry.program_name,
        dm: formatViDate(ev.occurredAt),
      });
    }
    if (out.length >= 3) break;
  }
  return out;
}

function newestFamilySignal(data: JournalPayload) {
  for (const ev of buildParentTimeline(data)) {
    if (ev.source === "journey" && isFamilyPreserve(ev.entry) && ev.entry.family_preserve) {
      return { ev, fp: ev.entry.family_preserve };
    }
  }
  return null;
}

function ParentHome() {
  const navigate = useNavigate();
  const { children, loadingChildren, selectedChildId } = useParentChild();

  const [data, setData] = useState<JournalPayload | null>(null);
  const [loadingJournal, setLoadingJournal] = useState(false);
  const [journalError, setJournalError] = useState(false);
  const [composerOpen, setComposerOpen] = useState(false);
  const [heroMedia, setHeroMedia] = useState<{ status: ReservedMediaStatus; src: string | null }>({
    status: "loading",
    src: null,
  });

  const loadJournal = useCallback(async () => {
    if (typeof window === "undefined" || !selectedChildId) return;
    setLoadingJournal(true);
    setJournalError(false);
    const { data: rpcData, error } = await supabase.rpc("get_child_journal", {
      p_child_id: selectedChildId,
    });
    if (error) {
      setData(null);
      setJournalError(true);
    } else {
      const payload = (rpcData ?? {}) as Partial<JournalPayload>;
      setData({
        journey: payload.journey ?? [],
        skills: payload.skills ?? [],
        badges: payload.badges ?? [],
        moments: payload.moments ?? [],
        creations: payload.creations ?? [],
      });
    }
    setLoadingJournal(false);
  }, [selectedChildId]);

  useEffect(() => {
    loadJournal();
  }, [loadJournal]);

  const firedHomeView = useRef<string | null>(null);
  useEffect(() => {
    if (!selectedChildId) return;
    if (firedHomeView.current === selectedChildId) return;
    firedHomeView.current = selectedChildId;
    logParentEvent("parent_home_view", { route: "/parent" });
  }, [selectedChildId]);

  const hero = data ? pickHero(data) : null;
  const heroMediaId = hero?.mediaId ?? null;

  const signHeroMedia = useCallback(async () => {
    if (typeof window === "undefined" || !heroMediaId) return;
    setHeroMedia({ status: "loading", src: null });
    const { data: signed, error } = await supabase.functions.invoke("get_signed_media_url", {
      body: { media_id: heroMediaId },
    });
    if (!error && signed?.allowed && signed?.signed_url) {
      setHeroMedia({ status: "ok", src: signed.signed_url as string });
    } else {
      setHeroMedia({ status: "failed", src: null });
    }
  }, [heroMediaId]);

  useEffect(() => {
    signHeroMedia();
  }, [signHeroMedia]);

  const selectedChild = children?.find((c) => c.id === selectedChildId) ?? null;
  const childName = selectedChild ? childLabel(selectedChild) : null;
  const recent = data ? buildRecent(data) : [];
  const familySignal = data ? newestFamilySignal(data) : null;
  const savedTotal = data
    ? data.creations.length +
      data.moments.filter((m) => m.media_id).length +
      data.journey.filter((e) => e.entry_type !== "badge").length
    : 0;
  const parentSaved = data ? data.journey.filter((e) => isParentMemory(e)).length : 0;
  const hasAnyItem = savedTotal > 0;
  const createLabel = `Ghi lại một điều về ${childName ?? "con"}`;

  const openComposer = () => {
    logParentEvent("parent_create_start", { route: "/parent" });
    setComposerOpen(true);
  };

  return (
    <div className="space-y-6">
      {/* 1 · Identity */}
      <div>
        <p className="text-xs font-semibold tracking-wide text-dma-ink-gold uppercase">
          Cổng ba mẹ
        </p>
        <h1 className="mt-1.5 font-dma-serif text-3xl leading-tight text-dma-ink sm:text-4xl">
          {childName ? `Hôm nay của ${childName}` : "Hôm nay"}
        </h1>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-dma-ink-2">
          Nơi lưu lại hành trình lớn lên và sáng tạo của con — để ba mẹ cùng con nhìn lại.
        </p>
      </div>

      {/* 2 · ChildSwitcher (shared, persisted context) */}
      <ChildSwitcher />

      {loadingChildren || (!!selectedChildId && loadingJournal && data === null) ? (
        <TruthState state="loading" title="Đang mở hành trình của con…" />
      ) : children && children.length === 0 ? (
        <TruthState
          state="empty"
          title="Chưa có hồ sơ con nào được liên kết với tài khoản này."
          description="Hồ sơ con do nhà trường tạo và liên kết. Ba mẹ vui lòng liên hệ nhà trường, hoặc gửi yêu cầu qua Hỗ trợ."
        >
          <div className="mt-5">
            <Link
              to="/portal/support"
              className="inline-flex min-h-11 items-center rounded-full bg-dma-emerald px-6 text-sm font-medium text-dma-ivory transition-colors hover:bg-dma-emerald-hover"
            >
              Mở Hỗ trợ →
            </Link>
          </div>
        </TruthState>
      ) : journalError ? (
        <TruthState
          state="error"
          title="Chưa mở được hành trình của con"
          description="Đã có lỗi khi tải dữ liệu. Ba mẹ thử lại giúp Dế Mèn nhé."
          action={{ label: "Thử lại", onClick: () => loadJournal() }}
        />
      ) : (
        <>
          {/* 3–4 · Hero memory + one primary CTA */}
          {hero ? (
            <>
              <MemoryHero
                kindLabel={hero.kindLabel}
                title={hero.title}
                blurb={hero.blurb}
                dateLabel={hero.dateLabel}
                mediaStatus={heroMedia.status}
                mediaSrc={heroMedia.src}
                focusId={hero.focusId}
                onRetryMedia={signHeroMedia}
              />
              {/* Contextual create — secondary when a hero exists */}
              <div>
                <button
                  type="button"
                  onClick={openComposer}
                  disabled={!selectedChildId}
                  className="inline-flex min-h-11 items-center gap-2 rounded-full border border-dma-hairline bg-dma-ivory-raised px-5 text-sm font-medium text-dma-ink-2 transition-colors hover:bg-dma-sage-tint"
                >
                  <Plus className="h-4 w-4" aria-hidden="true" />
                  {createLabel}
                </button>
              </div>
            </>
          ) : (
            <TruthState
              state="empty"
              title={
                hasAnyItem
                  ? `Hành trình của ${childName ?? "con"} đang bắt đầu`
                  : `Bắt đầu hành trình của ${childName ?? "con"}`
              }
              description={
                hasAnyItem
                  ? "Con đã có hoạt động được ghi nhận, nhưng chưa có hình ảnh nào để xem lại. Ba mẹ có thể ghi lại điều đầu tiên."
                  : "Mỗi bức tranh, câu nói, đoạn ghi âm hay khoảnh khắc nhỏ đều có thể trở thành một phần trong hành trình lớn lên của con."
              }
              action={selectedChildId ? { label: createLabel, onClick: openComposer } : null}
            />
          )}

          {/* 5 · Two quiet supporting areas */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Link
              to="/parent/journal"
              className="group rounded-3xl border border-dma-hairline bg-dma-ivory-raised p-6 transition-colors hover:bg-dma-sage-tint/60"
            >
              <div className="flex items-center gap-2">
                <h2 className="font-dma-serif text-lg text-dma-ink">Hành trình</h2>
                <ArrowRight
                  className="ml-auto h-4 w-4 text-dma-ink-meta transition-transform group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </div>
              <p className="mt-1.5 text-sm leading-relaxed text-dma-ink-2">
                Xem lại toàn bộ những điều đã được lưu giữ theo thời gian.
              </p>
              {hasAnyItem && (
                <p className="mt-3 text-xs text-dma-ink-meta">
                  Đã lưu {savedTotal} điều
                  {parentSaved > 0 ? ` · ${parentSaved} do ba mẹ ghi lại` : ""}
                </p>
              )}
            </Link>
            <div className="rounded-3xl border border-dma-hairline bg-dma-ivory-raised p-6">
              <div className="flex items-center gap-2">
                <HeartHandshake className="h-4.5 w-4.5 text-dma-ink-gold" aria-hidden="true" />
                <h2 className="font-dma-serif text-lg text-dma-ink">Cùng con hôm nay</h2>
              </div>
              <ul className="mt-3 space-y-2.5">
                {[
                  "Xem lại một tác phẩm con thích và hỏi con đã vẽ gì.",
                  "Hỏi con kể về một khoảnh khắc vui ở lớp.",
                  "Khích lệ con thử thêm màu sắc, âm thanh hoặc ý tưởng mới.",
                ].map((tip) => (
                  <li key={tip} className="flex items-start gap-2.5">
                    <span
                      className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-dma-sage"
                      aria-hidden="true"
                    />
                    <span className="text-sm leading-relaxed text-dma-ink-2">{tip}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>

          {/* 6 · Recent strip (real items only) */}
          {recent.length > 0 && (
            <section
              aria-label="Hành trình gần đây"
              className="rounded-3xl border border-dma-hairline bg-dma-ivory-raised p-6"
            >
              <h2 className="font-dma-serif text-lg text-dma-ink">Gần đây</h2>
              <ul className="mt-3 divide-y divide-dma-hairline/70">
                {recent.map((p) => (
                  <li key={p.focusId}>
                    <Link
                      to="/parent/journal"
                      search={{ focus: p.focusId }}
                      className="flex min-h-11 items-baseline gap-2.5 py-2.5 transition-colors hover:bg-dma-sage-tint/50"
                    >
                      <span className="text-base leading-none" aria-hidden="true">
                        {p.emoji}
                      </span>
                      <span className="min-w-0 flex-1 text-sm">
                        <span className="font-medium text-dma-ink">{p.label}</span>
                        {p.text && <span className="text-dma-ink-2"> — {p.text}</span>}
                      </span>
                      <span className="shrink-0 text-xs text-dma-ink-meta">{p.dm}</span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )}

          {/* 7 · Quiet family signal — preserved journal entries only */}
          {familySignal && (
            <Link
              to="/parent/journal"
              search={{ focus: familySignal.ev.id }}
              className="group block rounded-3xl border border-dma-champagne-soft bg-dma-ivory-raised p-6 transition-colors hover:bg-dma-sage-tint/50"
            >
              <p className="text-xs font-semibold tracking-wide text-dma-ink-gold uppercase">
                Từ Không gian gia đình
              </p>
              <p className="mt-2 font-dma-serif text-lg text-dma-ink">
                {familySignal.fp.card_title ||
                  familySignal.fp.contribution_body ||
                  "Một kỷ niệm được gia đình giữ lại"}
              </p>
              <p className="mt-1.5 text-xs text-dma-ink-meta">
                Được {familySignal.fp.preserved_by_name || "người thân"} giữ vào Hành trình ·{" "}
                {formatViDate(familySignal.ev.occurredAt)}
              </p>
            </Link>
          )}

          {/* Quiet links: Nhìn lại + Cổng của bé */}
          <div className="grid gap-4 sm:grid-cols-2">
            <Link
              to="/parent/discovery"
              className="group rounded-3xl border border-dma-hairline bg-dma-ivory-raised p-6 transition-colors hover:bg-dma-sage-tint/60"
            >
              <div className="flex items-center gap-2">
                <Sparkles className="h-4.5 w-4.5 text-dma-ink-gold" aria-hidden="true" />
                <h2 className="font-dma-serif text-lg text-dma-ink">Nhìn lại</h2>
                <ChevronRight
                  className="ml-auto h-4 w-4 text-dma-ink-meta transition-transform group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </div>
              <p className="mt-1.5 text-sm leading-relaxed text-dma-ink-2">
                Những điều hành trình của con đang dần cho thấy, từ dữ liệu đã được ghi nhận.
              </p>
            </Link>
            <Link
              to="/parent/kid"
              className="group rounded-3xl border border-dma-hairline bg-dma-ivory-raised p-6 transition-colors hover:bg-dma-sage-tint/60"
            >
              <div className="flex items-center gap-2">
                <KeyRound className="h-4.5 w-4.5 text-dma-ink-gold" aria-hidden="true" />
                <h2 className="font-dma-serif text-lg text-dma-ink">Thế giới của con</h2>
                <ChevronRight
                  className="ml-auto h-4 w-4 text-dma-ink-meta transition-transform group-hover:translate-x-0.5"
                  aria-hidden="true"
                />
              </div>
              <p className="mt-1.5 text-sm leading-relaxed text-dma-ink-2">
                Bật cổng riêng của bé, đặt PIN, khung giờ và ghép thiết bị.
              </p>
            </Link>
          </div>
        </>
      )}

      {selectedChildId && (
        <ParentMemoryComposer
          open={composerOpen}
          onOpenChange={setComposerOpen}
          childId={selectedChildId}
          childName={childName ?? "con"}
          onSaved={(_memoryId, journeyId) => {
            loadJournal();
            navigate({
              to: "/parent/journal",
              search: journeyId ? { focus: `journey:${journeyId}` } : {},
            });
          }}
        />
      )}
    </div>
  );
}
